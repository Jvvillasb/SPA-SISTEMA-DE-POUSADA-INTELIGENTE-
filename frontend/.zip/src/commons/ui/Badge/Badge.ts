import { Badge } from './Badge.styles';

export default Badge;
