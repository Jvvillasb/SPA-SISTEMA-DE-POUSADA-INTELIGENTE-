export interface UseDeviceProps {
    isPhone: boolean;
    isTable: boolean;
    isDesktop: boolean;
}
