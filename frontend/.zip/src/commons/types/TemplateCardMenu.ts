export interface TemplateCardMenuAction {
    label: string;
    onClick: VoidFunction;
}
