import { Client } from './Client';

export type CardProps = {
    client: Client;
};
