import { Client } from 'src/commons/types/Client';

export type ClientListItemProps = {
    client: Client;
};
